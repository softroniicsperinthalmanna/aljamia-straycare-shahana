-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2023 at 09:24 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `straycare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE `admin_tb` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`id`, `username`, `password`) VALUES
(1, 'admin123sc', '20012001');

-- --------------------------------------------------------

--
-- Table structure for table `adopted_tb`
--

CREATE TABLE `adopted_tb` (
  `adopt_id` int(10) NOT NULL,
  `req_id` int(15) NOT NULL,
  `adopted_on` date DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adopted_tb`
--

INSERT INTO `adopted_tb` (`adopt_id`, `req_id`, `adopted_on`, `status`) VALUES
(1, 2, '2023-02-22', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `adoptrequest_tb`
--

CREATE TABLE `adoptrequest_tb` (
  `req_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `send_status` varchar(50) NOT NULL,
  `send_date` datetime NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `reply_status` varchar(50) NOT NULL DEFAULT 'waiting',
  `reply_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adoptrequest_tb`
--

INSERT INTO `adoptrequest_tb` (`req_id`, `animal_id`, `sender_id`, `send_status`, `send_date`, `recipient_id`, `reply_status`, `reply_date`) VALUES
(1, 2, 8, 'requested', '2023-02-20 18:45:40', 1, 'waiting', '2023-02-19 00:00:00'),
(2, 4, 8, 'requested', '2023-02-20 18:48:24', 1, 'accepted', '2023-02-22 23:00:53'),
(3, 2, 8, 'requested', '2023-02-26 06:11:03', 1, 'waiting', '0000-00-00 00:00:00'),
(5, 1, 14, 'requested', '2023-03-26 14:31:14', 1, 'waiting', '0000-00-00 00:00:00'),
(6, 6, 14, 'requested', '2023-03-26 14:32:11', 31, 'waiting', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `animal_tb`
--

CREATE TABLE `animal_tb` (
  `animal_id` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `breed` varchar(50) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `animal_tb`
--

INSERT INTO `animal_tb` (`animal_id`, `description`, `gender`, `type`, `color`, `breed`, `image`) VALUES
(1, 'nsjbsbsnsn djdjnd djdjd d dhdhdndb', 'female', 'cat', 'white', 'persian', 0x696d6167657320283132292e6a706567),
(2, 'bzgvzh sbxjxbx ', 'female', 'cow', 'black n white', 'none', 0x696d6167657320283431292e6a706567),
(3, 'bdhdvbs sjdudb dhsuebbd', 'male', 'dog', 'brown', 'xyz', 0x696d6167657320283430292e6a706567),
(4, 'hdgv dbdhe dgdudbbd', 'male', 'dog', 'white n brown', 'pqr', 0x696d6167657320283332292e6a706567),
(5, 'hdxhchcucu', 'male', 'cow', 'brown', 'abc', 0x646f776e6c6f6164202833292e6a7067),
(6, 'vycdvmubfnhim', 'female', 'dog', 'brown n white', 'xyx', 0x696d6167657320283533292e6a7067),
(7, 'f h hcd jbh ', 'male', 'dog', 'brown', 'german shepherd', 0x696d6167657320283534292e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `collected_tb`
--

CREATE TABLE `collected_tb` (
  `collection_id` int(10) NOT NULL,
  `animal_id` int(15) NOT NULL,
  `office_id` int(10) NOT NULL,
  `collected_on` date DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'fostering',
  `died_on` date DEFAULT NULL,
  `adopted_on` date DEFAULT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collected_tb`
--

INSERT INTO `collected_tb` (`collection_id`, `animal_id`, `office_id`, `collected_on`, `status`, `died_on`, `adopted_on`, `reason`) VALUES
(1, 1, 1, '2022-12-07', 'fostering', NULL, NULL, ''),
(2, 2, 1, '2023-01-08', 'adopted', NULL, NULL, ''),
(3, 3, 1, '2022-11-15', 'fostering', NULL, NULL, ''),
(4, 4, 1, '2023-01-16', 'adopted', NULL, NULL, ''),
(5, 5, 1, '2023-03-08', 'dead', '2023-02-20', NULL, 'skin disease'),
(6, 6, 31, '2023-03-01', 'fostering', NULL, NULL, ''),
(7, 7, 31, '2023-02-08', 'dead', '2023-03-26', NULL, 'skin disease');

-- --------------------------------------------------------

--
-- Table structure for table `deathreport_tb`
--

CREATE TABLE `deathreport_tb` (
  `death_id` int(10) NOT NULL,
  `animal_id` int(15) NOT NULL,
  `died_on` date NOT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deathreport_tb`
--

INSERT INTO `deathreport_tb` (`death_id`, `animal_id`, `died_on`, `reason`) VALUES
(1, 5, '2023-02-20', 'heart attack');

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE `donation` (
  `donation_id` int(10) NOT NULL,
  `type` varchar(50) NOT NULL,
  `user_id` int(10) NOT NULL,
  `amount` int(15) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`donation_id`, `type`, `user_id`, `amount`, `date`) VALUES
(1, 'gpay', 1, 4200000, '2023-03-29'),
(2, 'Google Pay', 14, 5000, '2023-03-29'),
(3, 'PayTM ', 14, 2000, '2023-03-29');

-- --------------------------------------------------------

--
-- Table structure for table `forest`
--

CREATE TABLE `forest` (
  `f_id` int(11) NOT NULL,
  `loc` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `forest`
--

INSERT INTO `forest` (`f_id`, `loc`, `phone`, `email`, `log_id`) VALUES
(1, 'mukkam', 8569851201, 'frst237@gmail.com', 21),
(2, 'Nilambur', 8545654125, 'nlmbr125forest@gmail.com', 22),
(3, 'Trivandrum', 9856231010, 'forest12tvm12@gmail.com', 23);

-- --------------------------------------------------------

--
-- Table structure for table `foster`
--

CREATE TABLE `foster` (
  `animal_id` int(12) NOT NULL,
  `image` blob NOT NULL,
  `description_vet` varchar(300) NOT NULL,
  `veterinary_id` int(10) NOT NULL,
  `place_collected` varchar(300) NOT NULL,
  `date_collected` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foster`
--

INSERT INTO `foster` (`animal_id`, `image`, `description_vet`, `veterinary_id`, `place_collected`, `date_collected`) VALUES
(1, 0x746667686b6c, 'Animals Asia has rescued many dogs, cats, puppies and kittens who have suffered horrendous abuse at the hands of people who see them as \'pests\' — such as puppy abuse, when the dog pictured below was scalded with boiling water and thrown from a high rise building. And kitten abuse, with a disabled ki', 1, 'pmna', '2022-12-07 21:07:11'),
(3, 0x746667686b6c, 'It is not unusual to see captive wild animals in Asia\'s zoos in small barren cages, with no environmental enrichment, and inappropriate groupings - such as sociable pack animals housed alone.', 2, 'mlpm', '2022-12-30 21:08:02');

-- --------------------------------------------------------

--
-- Table structure for table `localselfgovernment`
--

CREATE TABLE `localselfgovernment` (
  `local_id` int(10) NOT NULL,
  `local_name` varchar(50) NOT NULL,
  `institution_type` varchar(30) NOT NULL,
  `loc` varchar(150) NOT NULL,
  `log_id` int(11) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `localselfgovernment`
--

INSERT INTO `localselfgovernment` (`local_id`, `local_name`, `institution_type`, `loc`, `log_id`, `phone`, `email`) VALUES
(1, 'lsg 1', 'abcdefg', 'Trissur', 11, 9874562100, 'lsg12tsr12@gmail.com'),
(2, 'lsgpmna', 'malabar', 'Palakkad', 12, 8565211232, 'lsg10pkd2001@gmail.com'),
(3, 'abc lsg type', 'lsg', 'Manjeri', 18, 9874501212, 'abclsg100@gmail.com'),
(4, 'xyz xyz', 'xyz type1', 'Mannarkkad', 19, 7845129090, 'xyzlsg1111@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `log_id` int(10) NOT NULL,
  `code` varchar(8) NOT NULL,
  `password` varchar(50) NOT NULL,
  `authority_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`log_id`, `code`, `password`, `authority_type`) VALUES
(1, 'OFCpma11', 'sc123456', 'office'),
(2, 'OFCpkd', 'sc1234', 'office'),
(5, 'vet2020', '987987', 'vet'),
(6, 'vet1234', '258258', 'vet'),
(7, 'pc10012', '147147', 'police'),
(8, 'police98', '98769876', 'police'),
(10, 'forest98', '98769876', 'forest'),
(11, 'lsg1234', '123123', 'lsg'),
(12, 'lsg9876', '98769876', 'lsg'),
(13, 'pc100x12', '123123', 'police'),
(14, 'vet12vx', '123456', 'vet'),
(15, '25vet10', '123123', 'vet'),
(18, 'x10lsg10', '123123', 'lsg'),
(19, 'xlsg1111', '10109898', 'lsg'),
(20, 'vet2310', '123123', 'vet'),
(21, 'fst12012', '123123', 'forest'),
(22, 'forest16', '987499977', 'forest'),
(23, 'frst12ff', '12451245', 'forest'),
(24, 'vetx333', '147147', 'vet'),
(27, 'asdawd', 'sdawd', 'vet'),
(31, 'OFCpkd3', '123123123', 'office');

-- --------------------------------------------------------

--
-- Table structure for table `missing`
--

CREATE TABLE `missing` (
  `missing_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `location` varchar(200) NOT NULL,
  `missingDate` date NOT NULL DEFAULT current_timestamp(),
  `phone` bigint(10) NOT NULL,
  `animal` varchar(50) NOT NULL,
  `animalColor` varchar(50) NOT NULL,
  `breed` varchar(50) NOT NULL,
  `image` blob NOT NULL,
  `user_id` int(10) NOT NULL,
  `reportedDate` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `status` varchar(20) NOT NULL DEFAULT 'missing'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `missing`
--

INSERT INTO `missing` (`missing_id`, `name`, `description`, `gender`, `location`, `missingDate`, `phone`, `animal`, `animalColor`, `breed`, `image`, `user_id`, `reportedDate`, `status`) VALUES
(1, 'rinto', 'brownish, hairy,small eyed,white toes', 'male', 'Kozhikode,Near Beach Road', '2022-12-14', 9076554410, 'dog', 'brown', 'schnoodle', 0x696d6167657320283430292e6a706567, 7, '2023-02-12 18:02:35.131611', 'missing'),
(2, 'manikutty', 'balck and white', 'female', 'Palakkad, near Safa Auditorium ', '2022-12-31', 8567909012, 'cow', 'black and white', 'none', 0x696d6167657320283431292e6a706567, 6, '2023-02-12 18:04:37.985086', 'missing'),
(3, 'mily', 'chkkvjvlbk ', 'male', 'perinthalmanna bypass,near angadipuram bridge', '2023-03-16', 9746532105, 'dog', 'light brown', 'pomeranian', 0x646f776e6c6f6164202836292e6a7067, 14, '2023-03-21 15:32:45.521103', 'missing'),
(4, 'jimmy', 'cyjbjxuvn', 'male', 'manjeri ,near stadium', '2023-03-10', 7890987870, 'dog', 'brown snd black', 'german shepherd', 0x696d6167657320283534292e6a7067, 11, '2023-03-21 15:36:24.792410', 'missing'),
(5, 'tommy', 'txvuc txcu ', 'male', 'palakkad near Dex mall', '2023-03-11', 9087901212, 'dog', 'white', 'samoyed', 0x646f776e6c6f6164202835292e6a7067, 9, '2023-03-21 16:22:22.716094', 'missing');

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `office_id` int(10) NOT NULL,
  `location` varchar(200) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`office_id`, `location`, `phone`, `email`, `log_id`) VALUES
(1, 'Perinthalmanna', 8547421891, 'ofcpmna11@gmail.com', 1),
(2, 'palakkad', 7896523256, 'ofcpkd@gmail.com', 2),
(6, 'Palakkad', 8745632101, 'ofcpmna1@gmail.com', 31);

-- --------------------------------------------------------

--
-- Table structure for table `register_tb`
--

CREATE TABLE `register_tb` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` blob NOT NULL,
  `address` varchar(300) NOT NULL,
  `log_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register_tb`
--

INSERT INTO `register_tb` (`user_id`, `name`, `image`, `address`, `log_id`) VALUES
(1, 'swalih', '', 'ABC homes,flat201,Malappuram', 7),
(2, 'Ashiq', '', 'XYZ villa,Calicut', 8),
(3, 'rishma', '', 'PQR House,Perinthalmanna', 9),
(4, 'shameela', '', 'EFG House,Manjeri', 10),
(5, 'Bibin', '', 'MNO house,Palakkad', 11),
(8, 'shameer', '', 'ABC house , Palakkad', 14),
(9, 'Mohammed Swalih VT', '', 'VT', 15),
(10, 'Mohammed Swalih VT', '', 'VT', 16),
(11, 'Mohammed Swalih VT', '', 'VT', 17),
(12, 'Mohammed Swalih VT', '', 'VT', 18),
(13, 'Mohammed Swalih VT', '', 'VT', 19),
(14, 'Mohammed Swalih VT', '', 'VT', 20),
(15, 'Mohammed Swalih VT', '', 'VT', 21),
(16, 'Mohammed Swalih VT', '', 'VT', 22),
(17, 'Mohammed Swalih VT', '', 'VT', 23),
(18, 'Mohammed Swalih VT', '', 'VT', 24),
(19, 'Mohammed Swalih VT', '', 'VT', 25),
(20, 'Mohammed Swalih VT', '', 'VT', 26),
(21, 'Mohammed Swalih VT', '', 'VT', 27),
(22, 'Mohammed Swalih VT', '', 'VT', 28),
(23, 'Mohammed Swalih VT', '', 'VT', 29),
(24, 'Mohammed Swalih VT', '', 'VT', 30),
(25, 'Mohammed Swalih VT', '', 'VT', 31),
(26, 'Mohammed Swalih VT', '', 'VT', 32),
(27, 'Mohammed Swalih VT', '', 'VT', 33),
(28, 'Mohammed Swalih VT', '', 'VT', 34),
(29, 'Mohammed Swalih VT', '', 'VT', 35),
(30, 'Mohammed Swalih VT', '', 'VT', 36),
(31, 'Mohammed Swalih VT', '', 'VT', 37);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(10) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(250) NOT NULL,
  `lati` varchar(100) NOT NULL,
  `longi` varchar(100) NOT NULL,
  `reportedDate` datetime(6) NOT NULL,
  `image` blob NOT NULL,
  `case_type` varchar(25) NOT NULL,
  `user_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `description`, `location`, `lati`, `longi`, `reportedDate`, `image`, `case_type`, `user_id`) VALUES
(1, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'abuse', 8),
(2, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'injured', 2),
(3, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'wild', 7),
(4, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'aggressive', 8),
(5, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'wild', 9),
(6, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'wild', 7),
(7, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', '', 'abuse', 8),
(8, 'nfekfkewfknk', 'knbvshvsk', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6162757365616e692e6a7067, 'aggressive', 9),
(9, 'this is a logo', 'pmna', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x6c6f676f2e6a7067, 'wild', 7),
(10, 'oqju', 'pmna', '10.976169', '76.2556965', '0000-00-00 00:00:00.000000', 0x4869742d612d646565722e6a7067, 'abuse', 7),
(11, 'oqju vxb xax hasbxhdbjs shbxhjbxd', 'kozhikode', '10.976169', '76.2556965', '2025-02-05 00:00:00.000000', 0x4869742d612d646565722e6a7067, 'wild', 8),
(12, 'oqju vxb xax hasbxhdbjs shbxhjbxd', 'kozhikode', '10.976169', '76.2556965', '2025-02-05 00:00:00.000000', 0x616767616e692e6a7067, 'aggressive', 8),
(13, 'wxwxwwswsws', 'kozhikode', '10.976169', '76.2556965', '2025-02-05 00:00:00.000000', 0x616767616e692e6a7067, 'aggressive', 9),
(14, 'injured 🐄 found near roadside ', 'Amminikkad,X7C7+4PQ,,', '10.976169', '76.2556965', '2023-02-12 09:25:47.671599', '', 'injured', 8),
(15, 'cat found slapped head', 'Amminikkad,X7C7+4PQ,,', '10.976169', '76.2556965', '2023-02-12 09:22:35.527520', '', 'aggressive', 9),
(16, '🐈 found near stadium road injured on head', 'Amminikkad,X7C7+4PQ,,', '10.976169', '76.2556965', '2023-02-12 09:25:47.671599', 0x696d6167657320283130292e6a706567, 'injured', 7),
(17, 'cow found wounded', 'kozhikode', '10.976169', '76.2556965', '2023-02-12 16:41:51.650956', 0x696d6167657320283131292e6a706567, 'injured', 8),
(18, 'head injured cat found,white 🐈, weak', 'kozhikode', '10.976169', '76.2556965', '2023-02-12 16:54:47.188207', 0x696d6167657320283130292e6a706567, 'injured', 9),
(19, 'bsgdhsndb', 'Amminikkad,X7G5+999,,', '10.976169', '76.2556965', '2023-02-12 16:59:39.129858', 0x696d6167657320283131292e6a706567, 'injured', 8),
(20, 'uvucucjvjvivuvuv', 'Amminikkad,X7G5+999,,', '10.976169', '76.2556965', '2023-02-12 17:28:32.666378', 0x696d6167657320283130292e6a706567, 'injured', 9),
(21, 'cow found agressive in Kozhikode town', 'Amminikkad,X7G5+999,,', '10.976169', '76.2556965', '2023-02-12 17:31:36.853710', 0x696d6167657320283131292e6a706567, 'wild', 7),
(22, 'hdgsgdhdh', 'Malappuram,EMS Hospital IP Block,,', '10.976169', '76.2556965', '2023-03-21 03:10:44.081697', 0x646f776e6c6f6164202836292e6a7067, 'injured', 1),
(23, 'dhgsgdhdhx', 'Malappuram,EMS Hospital IP Block,,', '10.976169', '76.2556965', '2023-03-21 03:11:53.530083', 0x646f776e6c6f6164202834292e6a7067, 'aggressive', 1),
(24, 'uffuvj jvj', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.977884', '76.2026346', '2023-03-21 15:28:16.231889', 0x696d6167657320283530292e6a7067, 'injured', 1),
(25, 'tccuvub', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778836', '76.202633', '2023-03-21 15:29:18.433596', 0x696d6167657320283533292e6a7067, 'aggressive', 1),
(26, 'yjbbuvj ', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778786', '76.2026335', '2023-03-21 15:29:35.136926', 0x696d6167657320283535292e6a7067, 'wild', 1),
(27, 'yfhv ucxhv ', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778946', '76.2026371', '2023-03-21 15:29:55.863956', 0x646f776e6c6f6164202834292e6a7067, 'abuse', 1),
(28, 'ycvibibib', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778946', '76.2026371', '2023-03-21 15:34:01.742113', 0x696d6167657320283437292e6a7067, 'abuse', 1),
(29, 'rxybucexun', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778919', '76.2026374', '2023-03-21 16:18:47.750651', 0x696d6167657320283439292e6a7067, 'injured', 9),
(30, 'fcbj  d j f ', 'Amminikkad,X7C7+4PQ,,', '10.9707346', '76.2651098', '2023-03-26 14:03:25.113570', 0x696d6167657320283535292e6a7067, 'injured', 14),
(31, 'hshhdhe', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9779128', '76.2026342', '2023-03-29 10:25:37.258795', 0x494d472d32303233303332392d5741303030362e6a7067, 'injured', 7),
(32, 'jajjshshs', 'Angadipuram,X6H3+533,Chanthully Paadam,', '10.9778877', '76.2026227', '2023-03-29 10:27:59.621074', 0x494d472d32303233303332392d5741303030322e6a7067, 'injured', 7);

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(10) NOT NULL,
  `station_name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`station_id`, `station_name`, `email`, `phone`, `log_id`) VALUES
(1, 'Melattur', 'melaturpc123@gmail.com', 9874561010, 7),
(2, 'perinthalmanna', 'pmnaPc452@gmail.com', 9845120210, 8),
(3, 'TestName', 'abc@gmail.com', 9856231010, 0),
(4, 'malappuram', 'mlpPolice12300@gmail.com', 9874563210, 13);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `log_id` int(11) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `password` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`log_id`, `phone`, `password`) VALUES
(7, 9074230412, 42),
(8, 7098767876, 123123),
(9, 7090990088, 123123),
(10, 9087880012, 123123),
(11, 9852010121, 123123),
(13, 9085800077, 123123),
(14, 9072064411, 123123),
(15, 9074230412, 123123),
(16, 9074230412, 123123),
(17, 9074230412, 123123),
(18, 9074230412, 123123),
(19, 9074230412, 123123),
(20, 9074230412, 123123),
(21, 9074230412, 123123),
(22, 9074230412, 123123),
(23, 9074230412, 123123),
(24, 9074230412, 123123),
(25, 9074230412, 123123),
(26, 9074230412, 123123),
(27, 9074230412, 123123),
(28, 9074230412, 123123),
(29, 9074230412, 123123),
(30, 9074230412, 123123),
(31, 9074230412, 123123),
(32, 9074230412, 123123),
(33, 9074230412, 123123),
(34, 9074230412, 123123),
(35, 9074230412, 123123),
(36, 9074230412, 123123),
(37, 9074230412, 123123);

-- --------------------------------------------------------

--
-- Table structure for table `veterinary`
--

CREATE TABLE `veterinary` (
  `vet_id` int(10) NOT NULL,
  `clinic_name` varchar(50) NOT NULL,
  `loc` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `veterinary`
--

INSERT INTO `veterinary` (`vet_id`, `clinic_name`, `loc`, `email`, `phone`, `log_id`) VALUES
(1, 'aniCare', 'Kottakkal', 'vetkotkl11@gmail.com', 9856320202, 5),
(2, 'PetCare', 'Melatur', 'vetmltr@gmail.com', 8562105333, 6),
(3, 'manjeri', '', 'vetmnjri@gmail.com', 9801214056, 0),
(4, 'mlpm', '', 'vetmlpm@gmail.com', 9856120120, 0),
(5, 'malabar', 'Malappuram', 'malabar1010@gmail.com', 7856985612, 14),
(6, 'testname', 'Kozhikode', 'test@gmail.com', 8563214521, 15),
(7, 'ABC', 'Kollam', 'abc123abc@gmail.com', 7845895610, 20),
(8, 'Mrigaya Hospital', 'Nilambur', 'mrigaya2001mm@gmail.com', 8523652301, 24),
(9, 'dsfsdf', 'dFASd', 'adadc@fgsfzkf', 0, 27);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tb`
--
ALTER TABLE `admin_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adopted_tb`
--
ALTER TABLE `adopted_tb`
  ADD PRIMARY KEY (`adopt_id`);

--
-- Indexes for table `adoptrequest_tb`
--
ALTER TABLE `adoptrequest_tb`
  ADD PRIMARY KEY (`req_id`);

--
-- Indexes for table `animal_tb`
--
ALTER TABLE `animal_tb`
  ADD PRIMARY KEY (`animal_id`);

--
-- Indexes for table `collected_tb`
--
ALTER TABLE `collected_tb`
  ADD PRIMARY KEY (`collection_id`);

--
-- Indexes for table `deathreport_tb`
--
ALTER TABLE `deathreport_tb`
  ADD PRIMARY KEY (`death_id`);

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`donation_id`);

--
-- Indexes for table `forest`
--
ALTER TABLE `forest`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `foster`
--
ALTER TABLE `foster`
  ADD PRIMARY KEY (`animal_id`);

--
-- Indexes for table `localselfgovernment`
--
ALTER TABLE `localselfgovernment`
  ADD PRIMARY KEY (`local_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `missing`
--
ALTER TABLE `missing`
  ADD PRIMARY KEY (`missing_id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `register_tb`
--
ALTER TABLE `register_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `veterinary`
--
ALTER TABLE `veterinary`
  ADD PRIMARY KEY (`vet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tb`
--
ALTER TABLE `admin_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `adopted_tb`
--
ALTER TABLE `adopted_tb`
  MODIFY `adopt_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `adoptrequest_tb`
--
ALTER TABLE `adoptrequest_tb`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `animal_tb`
--
ALTER TABLE `animal_tb`
  MODIFY `animal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `collected_tb`
--
ALTER TABLE `collected_tb`
  MODIFY `collection_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `deathreport_tb`
--
ALTER TABLE `deathreport_tb`
  MODIFY `death_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `donation`
--
ALTER TABLE `donation`
  MODIFY `donation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `forest`
--
ALTER TABLE `forest`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `foster`
--
ALTER TABLE `foster`
  MODIFY `animal_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `localselfgovernment`
--
ALTER TABLE `localselfgovernment`
  MODIFY `local_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `log_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `missing`
--
ALTER TABLE `missing`
  MODIFY `missing_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `office_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `register_tb`
--
ALTER TABLE `register_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `station_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `veterinary`
--
ALTER TABLE `veterinary`
  MODIFY `vet_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
