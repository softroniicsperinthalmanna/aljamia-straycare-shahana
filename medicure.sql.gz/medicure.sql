-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 11:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicure`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambulance_tb`
--

CREATE TABLE `ambulance_tb` (
  `amb_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `place` varchar(100) NOT NULL,
  `vhcl_no` varchar(10) NOT NULL,
  `phn_no` bigint(10) NOT NULL,
  `img` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ambulance_tb`
--

INSERT INTO `ambulance_tb` (`amb_id`, `log_id`, `hsptl_id`, `name`, `age`, `place`, `vhcl_no`, `phn_no`, `img`) VALUES
(1, 21, 4, 'Liyana TK', 30, 'Angadipuram', 'KL 10 0000', 1234567890, ''),
(2, 22, 5, 'Raniya', 30, 'Perithalmnanna', 'KL 10 6000', 6766452290, ''),
(3, 25, 8, 'Niyas TK', 45, 'Kottakkal', 'KL 10 3002', 9887654324, ''),
(4, 40, 4, 'Ashikh', 29, 'Pandikkad', 'KL 10 K009', 9800998902, ''),
(5, 41, 16, 'Tanseer', 20, 'Poopalam', 'KL 10 T666', 9900887766, 0x646f63746f722d766964656f2d63616c6c2d70617469656e742d706f7274726169742d7669727475616c2d6170706f696e746d656e742d6e65772d6e6f726d616c2d6c6966657374796c652d6865616c74682d636172652d6d65646963696e652d636f6e636570742d3231343536343537312e6a7067),
(6, 42, 16, 'Yahya', 23, 'Uganda', 'KL 10 T105', 9876543210, 0x6172696a697473696e676831313635303838353537322e77656270),
(7, 43, 16, 'Yahya', 23, 'Nilambur', 'KL 10 T105', 9876543210, 0x646f776e6c6f6164202832292e6a666966),
(8, 44, 16, 'Yahya', 23, 'Pattikkad', 'KL 10 T105', 9876543210, 0x646f776e6c6f6164202832292e6a666966),
(9, 45, 6, 'shafna', 21, 'Kamanam', 'KL 10 T999', 8289816332, ''),
(11, 47, 2, 'Hanan', 23, 'Malappuram', 'KL 10 R444', 8899007788, 0x6172696a697473696e676831313635303838353537322e77656270),
(12, 48, 2, 'Hanan', 23, 'pmna', 'KL 10 R444', 8899007788, 0x6172696a697473696e676831313635303838353537322e77656270),
(13, 49, 3, 'Swalih', 25, 'Pattikkad', 'KL 10 Y888', 7233445900, ''),
(14, 50, 0, '', 0, '', '', 0, ''),
(15, 51, 0, '', 0, '', '', 0, ''),
(16, 52, 0, '', 0, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `booking_tb`
--

CREATE TABLE `booking_tb` (
  `booking_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `dr_id` int(10) NOT NULL,
  `ptnt_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_tb`
--

INSERT INTO `booking_tb` (`booking_id`, `hsptl_id`, `dr_id`, `ptnt_id`, `date`, `time`, `type`) VALUES
(1, 1, 1, 0, '2023-01-01', '00:00:00', 'Offline'),
(2, 4, 4, 0, '2023-01-08', '00:00:00', 'Offline'),
(3, 6, 3, 0, '2023-01-10', '00:00:00', 'Online'),
(4, 4, 2, 0, '2023-01-12', '00:00:00', 'Offline'),
(5, 3, 3, 0, '2023-01-12', '00:00:00', 'Offline'),
(6, 5, 2, 0, '2023-01-14', '00:00:00', 'Online'),
(7, 2, 1, 1, '2023-01-14', '00:00:00', 'Online'),
(9, 2, 3, 2, '2023-01-30', '09:30:00', 'Online'),
(10, 2, 4, 3, '2023-01-30', '09:30:00', 'Offline'),
(11, 2, 2, 4, '2023-01-30', '09:30:00', 'Online'),
(12, 2, 3, 5, '2023-01-30', '09:30:00', 'Online'),
(13, 2, 3, 4, '2023-01-30', '09:30:00', 'Online');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_tb`
--

CREATE TABLE `campaign_tb` (
  `campaign_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `place` varchar(100) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `details` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campaign_tb`
--

INSERT INTO `campaign_tb` (`campaign_id`, `hsptl_id`, `place`, `time`, `date`, `details`) VALUES
(1, 0, '', '00:00:00', '0000-00-00', ''),
(2, 2, 'perithalmanna', '09:00:00', '2022-10-19', 'weight:50+\n'),
(3, 3, 'kozhikode', '10:00:00', '2023-01-25', 'weight:55+');

-- --------------------------------------------------------

--
-- Table structure for table `department_tb`
--

CREATE TABLE `department_tb` (
  `dpt_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_tb`
--

INSERT INTO `department_tb` (`dpt_id`, `hsptl_id`, `name`) VALUES
(1, 2, 'Cardiology'),
(2, 5, 'Orthology'),
(3, 2, 'Opthometry'),
(4, 7, 'Pediatrician'),
(5, 2, 'Gynacology'),
(6, 2, 'pulmanology');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_tb`
--

CREATE TABLE `doctor_tb` (
  `dr_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `dpt_id` int(11) NOT NULL,
  `img` longblob NOT NULL,
  `name` varchar(50) NOT NULL,
  `qual` varchar(50) NOT NULL,
  `exp` varchar(30) NOT NULL,
  `shift` varchar(25) NOT NULL,
  `phn_no` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_tb`
--

INSERT INTO `doctor_tb` (`dr_id`, `log_id`, `hsptl_id`, `dpt_id`, `img`, `name`, `qual`, `exp`, `shift`, `phn_no`) VALUES
(1, 23, 0, 0, '', 'Ashikh', 'MBBS,MD', '2 Years', 'Night', 0),
(2, 24, 7, 0, '', 'Ashikh', 'MBBS,MD', '2 Years', 'Night', 8899776655),
(3, 0, 0, 0, '', '', '', '', '', 0),
(4, 0, 0, 0, '', 'shafna', '', '', '', 9933002244),
(5, 27, 2, 3, '', 'marwan', 'MBBS', '2 Years', 'Day', 7654329988),
(6, 29, 2, 5, 0x44522e6a7067, 'Liyana', 'MBBS', '2 Years', 'Day', 7654329988),
(7, 30, 2, 5, 0x44522e6a7067, 'Yahya', 'MBBS', '2 Years', 'Day', 7654329988),
(8, 31, 5, 3, 0x44522e6a7067, 'Tanseer', 'MBBS', '2 Years', 'Day', 7654329988),
(11, 35, 6, 3, 0x44522e6a7067, 'Raniya', 'MBBS', '2 Years', 'Day', 7654329988),
(12, 36, 7, 3, 0x44522e6a7067, 'marwan', 'MBBS', '2 Years', 'Day', 7654329988),
(13, 37, 1, 3, 0x44522e6a7067, 'Liyana', 'MBBS', '2 Years', 'Day', 7654329988),
(14, 38, 2, 2, 0x44522e6a7067, 'Ashikh', 'MBBS', '2 Years', 'Day', 7654329988),
(15, 39, 3, 3, 0x646f63746f722d6368617261637465722d6261636b67726f756e645f313237302d38342e77656270, 'marwan', 'MBBS', '2 Years', 'Day', 7654329988);

-- --------------------------------------------------------

--
-- Table structure for table `donation_tb`
--

CREATE TABLE `donation_tb` (
  `dnt_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `b_grp` varchar(10) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `place` varchar(50) NOT NULL,
  `phn_no` bigint(10) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donation_tb`
--

INSERT INTO `donation_tb` (`dnt_id`, `user_id`, `hsptl_id`, `name`, `age`, `gender`, `b_grp`, `weight`, `place`, `phn_no`, `email`) VALUES
(1, 0, 0, 'Saina', 36, 'Female', 'B+', '60', 'Malappuram', 8909889009, 'sainatha1@gmail.com'),
(2, 0, 4, 'shafna', 21, 'Female', 'O+', '65', 'Kamanam', 82898216332, 'shafashikh@gmail.com'),
(3, 0, 5, 'Ashikh', 29, 'Male', 'O-', '70', 'Pandikkad', 9988004900, 'ashikh@gmail.com'),
(4, 5, 0, 'Liyana TK', 20, 'Female', 'A+', '55', 'Angadipurram', 8977009988, 'liyanapk2@gmail.com'),
(5, 6, 0, 'Raniya', 21, 'Female', 'AB+', '60', 'Kottakal', 7239887700, 'raniya2002@gmail.com'),
(6, 7, 0, 'Najva', 20, 'Female', 'AB-', '60', 'Pandikkad', 9900220099, 'najva@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_tb`
--

CREATE TABLE `hospital_tb` (
  `hsptl_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `hspt_name` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `pin` int(11) NOT NULL,
  `phn_no` bigint(11) NOT NULL,
  `img` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital_tb`
--

INSERT INTO `hospital_tb` (`hsptl_id`, `log_id`, `hspt_name`, `place`, `pin`, `phn_no`, `img`) VALUES
(1, 13, 'Memorial Hospital', 'Calicut', 676544, 9988775543, ''),
(2, 14, 'Kasturba Hospital', 'Manipal', 676767, 2147483647, ''),
(3, 15, 'Baby Hospital', 'Manipal', 676767, 2147483647, ''),
(4, 16, 'Moulana Hospital', 'Perithalmanna', 679322, 8899776076, 0x486f73706974616c2e6a7067),
(5, 17, 'KIMS Hospital', 'Manipal', 676767, 2147483647, ''),
(6, 18, 'Al-Shifa Hospital', 'Perithalmanna', 679322, 8899776076, 0x486f73706974616c2e6a7067),
(7, 19, 'MIMS Hospital', 'Kozhikode', 778899, 9900809800, 0x486f73706974616c2e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `link_tb`
--

CREATE TABLE `link_tb` (
  `link_id` int(11) NOT NULL,
  `ptnt_id` int(11) NOT NULL,
  `link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `log_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pswrd` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`log_id`, `email`, `pswrd`, `user_type`) VALUES
(1, 'shaf12@gmail.com', 'shaf@ash', ''),
(2, 'shaf12@gmail.com', 'shaf@ash', 'doctor'),
(3, 'shaf12@gmail.com', 'shaf@ash', 'doctor'),
(4, 'shaf12@gmail.com', 'shaf@ash', 'doctor'),
(5, 'shaf12@gmail.com', 'shaf@ash', 'doctor'),
(6, 'shaf12@gmail.com', 'shaf@ash', 'doctor'),
(7, 'lia@gmail.com', '123123', 'doctor'),
(8, 'lia@gmail.com', '123123', 'hospital'),
(9, 'yahya@gmail.com', '123123', 'hospital'),
(10, 'lia@gmail.com', '123123', 'hospital'),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, 'man@gmail.com', 'man111', 'Hospital'),
(15, 'man@gmail.com', 'man111', 'Hospital'),
(16, 'moulu@gmail.com', 'man111', 'Hospital'),
(17, 'man@gmail.com', 'man111', 'Hospital'),
(18, 'kims@gmail.com', 'man111', 'Hospital'),
(19, 'mims@gmail.com', '', 'hospital'),
(20, 'lia@gmail.com', '123123', 'hospital'),
(21, 'tk@gmail.com', 'tk123', 'Ambulance'),
(22, 'tk@gmail.com', 'tk123', 'Ambulance'),
(23, 'ash@gmail.com', 'ash123', 'Doctor'),
(24, 'ash@gmail.com', 'ash123', 'Doctor'),
(25, 'niyaliya@gmail.com', '', 'Ambulance'),
(26, 'mar@gmail.com', 'mar11', 'Doctor'),
(27, 'mar@gmail.com', 'mar11', 'Doctor'),
(28, 'mar@gmail.com', 'mar11', 'Doctor'),
(29, 'mar@gmail.com', 'mar11', 'Doctor'),
(30, 'mar@gmail.com', 'mar11', 'Doctor'),
(31, 'mar@gmail.com', 'mar11', 'Doctor'),
(32, 'mar@gmail.com', 'mar11', 'Doctor'),
(33, 'mar@gmail.com', 'mar11', 'Doctor'),
(34, 'mar@gmail.com', 'mar11', 'Doctor'),
(35, 'mar@gmail.com', 'mar11', 'Doctor'),
(36, 'mar@gmail.com', 'mar11', 'Doctor'),
(37, 'mar@gmail.com', 'mar11', 'Doctor'),
(38, 'mar@gmail.com', 'mar11', 'Doctor'),
(39, 'mar@gmail.com', 'mar11', 'Doctor'),
(40, '', '', ''),
(41, 'yahmol@gmail.com', 'yahMB', 'Ambulance Driver'),
(42, 'yahmol@gmail.com', 'yahMB', 'Ambulance Driver'),
(43, 'yahmol@gmail.com', 'yahMB', 'Ambulance Driver'),
(44, 'yahmol@gmail.com', 'yahMB', 'Ambulance Driver'),
(45, 'shaf@gmail.com', '', ''),
(46, '', '', ''),
(47, 'hanan@gmail.com', 'hanan123', 'Ambulance'),
(48, 'hanan@gmail.com', 'hanan123', 'Ambulance'),
(49, 's@gamil.com', '', ''),
(50, '', '', ''),
(51, '', '', ''),
(52, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `notification_tb`
--

CREATE TABLE `notification_tb` (
  `noti_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` varchar(100) NOT NULL,
  `send_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_tb`
--

INSERT INTO `notification_tb` (`noti_id`, `sender_id`, `receiver_id`, `message`, `send_date`) VALUES
(2, 6, 5, 'you have confirmed your booking', '2022-12-12'),
(3, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(5, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(6, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(7, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(8, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(9, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(10, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12'),
(11, 4, 7, 'ABC hospital has requested for you blood ', '2022-12-12');

-- --------------------------------------------------------

--
-- Table structure for table `online_tb`
--

CREATE TABLE `online_tb` (
  `onln_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `about` varchar(100) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `dept` varchar(25) NOT NULL,
  `dr_name` varchar(50) NOT NULL,
  `time` time NOT NULL,
  `payment` varchar(10) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `online_tb`
--

INSERT INTO `online_tb` (`onln_id`, `hsptl_id`, `user_id`, `name`, `age`, `weight`, `about`, `gender`, `dept`, `dr_name`, `time`, `payment`, `date`) VALUES
(1, 0, 0, 'Adhil', 28, '75', 'Allergetic', 'Male', 'Cardiology', 'Fathima', '07:30:00', '', NULL),
(2, 0, 0, 'Adhil', 28, '75', 'Allergetic', 'Male', 'Cardiology', 'Fathima', '07:30:00', 'Rs.500', NULL),
(3, 0, 0, 'Adhil', 28, '75', 'Allergetic', 'Male', 'Cardiology', 'Fathima', '07:30:00', 'Rs.500', '0000-00-00'),
(4, 0, 0, 'Adhil', 28, '75', 'Allergetic', 'Male', 'Cardiology', 'Fathima', '07:30:00', 'Rs.500', '2022-02-12');

-- --------------------------------------------------------

--
-- Table structure for table `op_tb`
--

CREATE TABLE `op_tb` (
  `op_id` int(11) NOT NULL,
  `op_no` int(11) NOT NULL,
  `ptnt_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient_tb`
--

CREATE TABLE `patient_tb` (
  `ptnt_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `phn_no` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_tb`
--

INSERT INTO `patient_tb` (`ptnt_id`, `name`, `age`, `gender`, `phn_no`) VALUES
(4, 'Liyana TK', 30, 'Female', 9900990542),
(5, 'Raniya TK', 32, 'Female', 9345687099),
(6, 'Tanseer', 34, 'Male', 7278769900);

-- --------------------------------------------------------

--
-- Table structure for table `payment_tb`
--

CREATE TABLE `payment_tb` (
  `pymnt_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `Payment_status` varchar(25) NOT NULL,
  `date` date NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescription_tb`
--

CREATE TABLE `prescription_tb` (
  `pscrp_id` int(11) NOT NULL,
  `op_no` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL,
  `dr_id` int(11) NOT NULL,
  `prescrptn` varchar(500) NOT NULL,
  `disease` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `review_tb`
--

CREATE TABLE `review_tb` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slotdr_tb`
--

CREATE TABLE `slotdr_tb` (
  `slotdr_id` int(11) NOT NULL,
  `slot_name` varchar(50) NOT NULL,
  `dr_id` int(11) NOT NULL,
  `hsptl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slot_tb`
--

CREATE TABLE `slot_tb` (
  `slot_id` int(11) NOT NULL,
  `slot_name` varchar(50) NOT NULL,
  `time1` time NOT NULL,
  `time2` time NOT NULL,
  `hsptl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE `user_tb` (
  `user_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(15) NOT NULL,
  `place` varchar(100) NOT NULL,
  `phn_no` bigint(10) NOT NULL,
  `b_grp` varchar(10) NOT NULL,
  `img` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`user_id`, `log_id`, `name`, `dob`, `gender`, `place`, `phn_no`, `b_grp`, `img`) VALUES
(1, 0, 'ABC hospital', '0000-00-00', '', 'Perithalmanna', 0, '', ''),
(2, 8, 'Liyana', '0000-00-00', 'Female', 'Palakkad', 2147483647, '', ''),
(3, 9, 'yahya TK', '2000-10-12', 'Male', 'Palakkad', 9900887790, 'AB+', 0x7361642d666163652d656d6f6a692d646f776e6c6f61642d68656172742d656d6f6a692d626c61636b2d7265642d70696e6b2d64657072657373696f6e2d736d696c65792d3131353632393134363636377268616235797976392e706e67),
(4, 10, 'Liyana', '2002-02-12', 'Female', 'Palakkad', 2147483647, '', ''),
(5, 20, 'Liyana', '2002-02-12', 'Female', 'Palakkad', 7890987666, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambulance_tb`
--
ALTER TABLE `ambulance_tb`
  ADD PRIMARY KEY (`amb_id`);

--
-- Indexes for table `booking_tb`
--
ALTER TABLE `booking_tb`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `campaign_tb`
--
ALTER TABLE `campaign_tb`
  ADD PRIMARY KEY (`campaign_id`);

--
-- Indexes for table `department_tb`
--
ALTER TABLE `department_tb`
  ADD PRIMARY KEY (`dpt_id`);

--
-- Indexes for table `doctor_tb`
--
ALTER TABLE `doctor_tb`
  ADD PRIMARY KEY (`dr_id`);

--
-- Indexes for table `donation_tb`
--
ALTER TABLE `donation_tb`
  ADD PRIMARY KEY (`dnt_id`);

--
-- Indexes for table `hospital_tb`
--
ALTER TABLE `hospital_tb`
  ADD PRIMARY KEY (`hsptl_id`);

--
-- Indexes for table `link_tb`
--
ALTER TABLE `link_tb`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `notification_tb`
--
ALTER TABLE `notification_tb`
  ADD PRIMARY KEY (`noti_id`);

--
-- Indexes for table `online_tb`
--
ALTER TABLE `online_tb`
  ADD PRIMARY KEY (`onln_id`);

--
-- Indexes for table `op_tb`
--
ALTER TABLE `op_tb`
  ADD PRIMARY KEY (`op_id`);

--
-- Indexes for table `patient_tb`
--
ALTER TABLE `patient_tb`
  ADD PRIMARY KEY (`ptnt_id`);

--
-- Indexes for table `payment_tb`
--
ALTER TABLE `payment_tb`
  ADD PRIMARY KEY (`pymnt_id`);

--
-- Indexes for table `prescription_tb`
--
ALTER TABLE `prescription_tb`
  ADD PRIMARY KEY (`pscrp_id`);

--
-- Indexes for table `review_tb`
--
ALTER TABLE `review_tb`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `slotdr_tb`
--
ALTER TABLE `slotdr_tb`
  ADD PRIMARY KEY (`slotdr_id`);

--
-- Indexes for table `slot_tb`
--
ALTER TABLE `slot_tb`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `user_tb`
--
ALTER TABLE `user_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ambulance_tb`
--
ALTER TABLE `ambulance_tb`
  MODIFY `amb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `booking_tb`
--
ALTER TABLE `booking_tb`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `campaign_tb`
--
ALTER TABLE `campaign_tb`
  MODIFY `campaign_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department_tb`
--
ALTER TABLE `department_tb`
  MODIFY `dpt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctor_tb`
--
ALTER TABLE `doctor_tb`
  MODIFY `dr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `donation_tb`
--
ALTER TABLE `donation_tb`
  MODIFY `dnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hospital_tb`
--
ALTER TABLE `hospital_tb`
  MODIFY `hsptl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `link_tb`
--
ALTER TABLE `link_tb`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `notification_tb`
--
ALTER TABLE `notification_tb`
  MODIFY `noti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `online_tb`
--
ALTER TABLE `online_tb`
  MODIFY `onln_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `op_tb`
--
ALTER TABLE `op_tb`
  MODIFY `op_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_tb`
--
ALTER TABLE `patient_tb`
  MODIFY `ptnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment_tb`
--
ALTER TABLE `payment_tb`
  MODIFY `pymnt_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescription_tb`
--
ALTER TABLE `prescription_tb`
  MODIFY `pscrp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `review_tb`
--
ALTER TABLE `review_tb`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `slotdr_tb`
--
ALTER TABLE `slotdr_tb`
  MODIFY `slotdr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `slot_tb`
--
ALTER TABLE `slot_tb`
  MODIFY `slot_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_tb`
--
ALTER TABLE `user_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
