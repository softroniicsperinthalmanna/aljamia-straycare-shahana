<?php
include 'connect.php';
//$office_id=$_POST['officeId'];
$request_id=$_POST['requestId'];
$status=$_POST['status'];
$adopt_date=$_POST['adoptDate'];
$sql1= mysqli_query($conn,"UPDATE adopted_tb set status='$status',adopted_on='$adopt_date'where req_id='$request_id'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>