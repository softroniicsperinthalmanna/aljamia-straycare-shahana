<?php
include 'connect.php';
//$log_id=$_POST['userName_id'];
$data=mysqli_query($conn,"SELECT report.description,report.image,report.location,report.lati,report.longi,report.reportedDate,register_tb.name,userlogin.phone FROM report INNER JOIN register_tb on register_tb.log_id=report.user_id INNER JOIN userlogin on report.user_id= userlogin.log_id where case_type = 'injured';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
      //  $list[]=$row;
    $myarray['description']=$row['description'];
    $myarray['image']=$row['image'];
    $myarray['location']=$row['location'];
    $myarray['lati']=$row['lati'];
    $myarray['longi']=$row['longi'];
    $myarray['reportedOn']=$row['reportedDate'];
    $myarray['phone']=$row['phone'];
    $myarray['reporter']=$row['name'];
    $myarray['result']="success";
    array_push($list,$myarray);

    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
  //  $list='Failed';
 
}
echo json_encode($list);
?>
