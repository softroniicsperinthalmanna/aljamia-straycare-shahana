
<?php
include 'connect.php';
$office_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT animal_tb.image as aniImage,adoptrequest_tb.animal_id,adoptrequest_tb.req_id,adoptrequest_tb.sender_id,adoptrequest_tb.send_status,adoptrequest_tb.send_date,adoptrequest_tb.reply_status,adoptrequest_tb.reply_date,adopted_tb.status,register_tb.name,register_tb.address FROM adoptrequest_tb inner join animal_tb on adoptrequest_tb.animal_id=animal_tb.animal_id inner join adopted_tb on adopted_tb.req_id=adoptrequest_tb.req_id inner join register_tb on register_tb.log_id=adoptrequest_tb.sender_id inner Join userlogin on adoptrequest_tb.sender_id=userlogin.log_id where adoptrequest_tb.recipient_id='$office_id' && adoptrequest_tb.send_status='requested'&& adoptrequest_tb.reply_status='accepted' && adopted_tb.status='pending';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
      //  $list[]=$row;
      $myarray['result']="success";
      $myarray['animalId']=$row['animal_id'];
    //  $myarray['description']=$data['description'];
   //   $myarray['gender']=$data['gender'];
   //   $myarray['animaltype']=$data['type'];
  //    $myarray['color']=$data['color'];
    //  $myarray['breed']=$data['breed'];
      $myarray['image']=$row['aniImage'];
      $myarray['reqId']=$row['req_id'];
      $myarray['userId']=$row['sender_id'];
      $myarray['sendStatus']=$row['send_status'];
      $myarray['sendDate']=$row['send_date'];
      $myarray['replyStatus']=$row['reply_status'];
      $myarray['replyDate']=$row['reply_date'];
      $myarray['status']=$row['status'];
      $myarray['Username']=$row['name'];
      $myarray['address']=$row['address'];

      array_push($list,$myarray);
    }   

} 
else{
   // $list['result']='Failed';
    $myarray['result']="failed";
    array_push($list,$myarray);
 
}
echo json_encode($list);
?>
