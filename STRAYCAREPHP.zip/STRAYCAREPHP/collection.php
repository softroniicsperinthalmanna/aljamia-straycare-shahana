<?php
include 'connect.php';
$desc=$_POST['description'];
$gender=$_POST['gender'];
$animal_type=$_POST['animalType'];
$animal_color=$_POST['animalColor'];
$breed=$_POST['breed'];
$office_id=$_POST['officeId'];
$collected_on=$_POST['collectedOn'];

$img=$_FILES['image']['name'];                  //img--->php;    img1---->from flutter...use this in postman
$imagepath='reportCase/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);



$sql1=mysqli_query($conn,"INSERT INTO animal_tb(description,gender,type,color,breed,image)values('$desc','$gender','$animal_type','$animal_color','$breed','$img')");
$animal_ID=mysqli_insert_id($conn);

$sql2=mysqli_query($conn,"INSERT INTO collected_tb(animal_id,office_id,collected_on)values('$animal_ID','$office_id','$collected_on')");
if($sql1 && $sql2){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>