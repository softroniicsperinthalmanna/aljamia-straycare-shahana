
<?php
include 'connect.php';
$office_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT * FROM adoptrequest_tb inner join animal_tb on adoptrequest_tb.animal_id=animal_tb.animal_id where adoptrequest_tb.recipient_id='$office_id' && adoptrequest_tb.send_status='requested'&& adoptrequest_tb.reply_status='waiting';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;
        $myarray['result']="success";
        $myarray['animalId']=$row['animal_id'];
      //  $myarray['description']=$data['description'];
     //   $myarray['gender']=$data['gender'];
     //   $myarray['animaltype']=$data['type'];
    //    $myarray['color']=$data['color'];
      //  $myarray['breed']=$data['breed'];
        $myarray['image']=$row['image'];
        $myarray['reqId']=$row['req_id'];
        $myarray['userId']=$row['sender_id'];
        $myarray['sendStatus']=$row['send_status'];
        $myarray['sendDate']=$row['send_date'];
        $myarray['replyStatus']=$row['reply_status'];
        $myarray['replyDate']=$row['reply_date'];
        array_push($list,$myarray);
    
       
    }   

} 
else{
  //  $list['result']='Failed';
    $myarray['result']="failed";
    array_push($list,$myarray);
 
}
echo json_encode($list);
?>
