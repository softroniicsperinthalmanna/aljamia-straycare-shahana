<?php
include 'connect.php';
$name=$_POST['name'];
$description=$_POST['description'];
$gender=$_POST['gender'];
$location=$_POST['location'];
$missingDate=$_POST['missingDate'];
$phone=$_POST['phone'];
$animal=$_POST['animal'];
$animalColor=$_POST['animalColor'];
$breed=$_POST['breed'];
$reportedDate=$_POST['reportedDate'];
// $case_type=$_POST['caseType'];
$user_id=$_POST['user_id'];

$img=$_FILES['image']['name'];                  //img--->php;    img1---->from flutter...use this in postman
$imagepath='missingCase/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);


$sql1=mysqli_query($conn,"INSERT INTO missing(name,description,gender,location,missingDate,phone,animal,animalColor,breed,image,user_id,reportedDate)values('$name','$description','$gender','$location','$missingDate','$phone','$animal','$animalColor','$breed','$img','$user_id','$reportedDate')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>