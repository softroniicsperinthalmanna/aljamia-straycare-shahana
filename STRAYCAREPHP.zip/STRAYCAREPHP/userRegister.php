<?php
 include 'connect.php';
$name=$_POST['name'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$password = $_POST['password'];



// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($conn, "INSERT INTO userlogin(phone,password) values('$phone','$password')");
$user_id = mysqli_insert_id($conn);
$sql2 = mysqli_query($conn,"INSERT INTO register_tb (name,address,log_id) values ('$name','$address','$user_id')");
if($sql1 && $sql2){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>