
<?php
include 'connect.php';
$office_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT * FROM collected_tb inner join animal_tb on collected_tb.animal_id=animal_tb.animal_id inner Join office on collected_tb.office_id=office.office_id where collected_tb.office_id='$office_id' ");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
        $list[]=$row;
    // $myarray['description']=$row['description'];
    // $myarray['location']=$row['location'];
    // $myarray['dateandtime']=$row['dateandtime'];
    // $myarray['phone']=$row['phone'];
    // $myarray['animal_type']=$row['animal_type'];
    // $myarray['status']=$row['status'];
    // $myarray['user_id']=$row['user_id'];

    // array_push($list,$myarray);

    }   

} 
else{
    $list='Failed';
    // $myarray['result']="failed";
    // array_push($list,$myarray);
 
}
echo json_encode($list);
?>
