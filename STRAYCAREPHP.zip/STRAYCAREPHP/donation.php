<?php
include 'connect.php';
$method=$_POST['method'];      //payment Method
$uid=$_POST['uid'];          //userid
$amt=$_POST['amt'];        //amount
$sql1=mysqli_query($conn,"INSERT INTO donation(type,user_id,amount)values('$method','$uid','$amt')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>