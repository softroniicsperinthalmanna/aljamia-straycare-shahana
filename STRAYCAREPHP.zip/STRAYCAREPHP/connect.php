<?php
$conn=new mysqli('localhost','root','','straycare');
// if($conn){
//     echo "success";
// }
// else{
//     echo "fail";
// }
?>

