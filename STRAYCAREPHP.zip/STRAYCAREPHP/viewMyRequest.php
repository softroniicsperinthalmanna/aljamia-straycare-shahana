
<?php
include 'connect.php';
$user_id=$_POST['userID'];


$data=mysqli_query($conn,"SELECT * FROM adoptrequest_tb inner join animal_tb on adoptrequest_tb.animal_id=animal_tb.animal_id where adoptrequest_tb.sender_id='$user_id' && adoptrequest_tb.send_status='requested';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
        $list[]=$row;
       
    }   

} 
else{
    $list['result']='Failed';
    // $myarray['result']="failed";
    // array_push($list,$myarray);
 
}
echo json_encode($list);
?>
