
<?php
include 'connect.php';
$user_id=$_POST['userID'];


$data=mysqli_query($conn,"SELECT * FROM adoptrequest_tb inner join animal_tb on adoptrequest_tb.animal_id=animal_tb.animal_id where adoptrequest_tb.sender_id='$user_id' && adoptrequest_tb.send_status='requested';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
      //  $list[]=$row;
      $myarray['result']="success";
      $myarray['req_id']=$row['req_id'];
      $myarray['animal_id']=$row['animal_id'];
      $myarray['sender_id']=$row['sender_id'];
      $myarray['send_status']=$row['send_status'];
      $myarray['send_date']=$row['send_date'];
      $myarray['recipient_id']=$row['recipient_id'];
      $myarray['reply_status']=$row['reply_status'];
      $myarray['reply_date']=$row['reply_date'];
      $myarray['description']=$row['description'];
      $myarray['gender']=$row['gender'];
      $myarray['type']=$row['type'];
      $myarray['color']=$row['color'];
      $myarray['breed']=$row['breed'];
      $myarray['image']=$row['image'];
      $myarray['type']=$row['type'];

    array_push($list,$myarray);
       
    }   

} 
else{
   // $list['result']='Failed';
    $myarray['result']="failed";
    array_push($list,$myarray);
 
}
echo json_encode($list);
?>
