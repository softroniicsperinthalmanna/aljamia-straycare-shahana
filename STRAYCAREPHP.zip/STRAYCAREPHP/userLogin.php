<?php
include 'connect.php';
  $phone=$_POST['phone'];
  $pass=$_POST['password'];
 $sql= mysqli_query($con,"SELECT * from userlogin where phone='$code' && password='$pass'");
  if($sql->num_rows>0){
    while($row=mysqli_fetch_assoc($sql)){
        $myarray['message']='User Successfully Logged In';
         $myarray['login_id']=$row['log_id'];
    }
  }
  else{
    $myarray['message']='Failed to Login';
  }
echo json_encode($myarray);
?>