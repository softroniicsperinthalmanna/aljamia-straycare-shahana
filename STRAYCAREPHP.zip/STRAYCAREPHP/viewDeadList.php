
<?php
include 'connect.php';
 $office_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT * FROM collected_tb inner join animal_tb on collected_tb.animal_id=animal_tb.animal_id inner Join office on collected_tb.office_id=office.office_id where status='dead' && collected_tb.office_id='$office_id'");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
        $list[]=$row;
    }   

} 
else{
    $list='Failed';
 
}
echo json_encode($list);
?>
