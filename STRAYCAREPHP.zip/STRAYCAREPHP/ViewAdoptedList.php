
<?php
include 'connect.php';
//$log_id=$_POST['userName_id'];


$data=mysqli_query($conn,"SELECT * FROM adopted_tb INNER JOIN adoptrequest_tb ON adopted_tb.req_id=adoptrequest_tb.req_id INNER JOIN animal_tb ON animal_tb.animal_id=adoptrequest_tb.animal_id WHERE adopted_tb.status='completed';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
        $myarray['result']="success";
        $myarray['reqId']=$row['req_id'];
        $myarray['status']=$row['status'];
        $myarray['adoptedOn']=$row['adopted_on'];
        $myarray['animalId']=$row['animal_id'];
        $myarray['description']=$row['description'];
        $myarray['gender']=$row['gender'];
        $myarray['animaltype']=$row['type'];
        $myarray['color']=$row['color'];
        $myarray['breed']=$row['breed'];
        $myarray['image']=$row['image'];
       // $list[]=$row;
       array_push($list,$myarray);

    }   

} 
else{
   $myarray['result']="failed";
   
    array_push($list,$myarray);
  //  $list='Failed';
 
}
echo json_encode($list);
?>
