
<?php
include 'connect.php';
$log_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT animal_tb.description,animal_tb.gender,animal_tb.type,animal_tb.color,animal_tb.breed,animal_tb.animal_id,animal_tb.image as animalImage,adopted_tb.req_id,adopted_tb.adopted_on,register_tb.name,register_tb.address,adoptrequest_tb.sender_id,userlogin.phone FROM adopted_tb INNER JOIN adoptrequest_tb ON adopted_tb.req_id=adoptrequest_tb.req_id INNER JOIN animal_tb ON animal_tb.animal_id=adoptrequest_tb.animal_id INNER JOIN register_tb on adoptrequest_tb.sender_id=register_tb.log_id INNER JOIN userlogin ON register_tb.log_id=userlogin.log_id WHERE adopted_tb.status='completed'&& adoptrequest_tb.recipient_id='$log_id';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
        $myarray['result']="success";
        $myarray['reqId']=$row['req_id'];
        $myarray['adoptedOn']=$row['adopted_on'];
        $myarray['animalId']=$row['animal_id'];
        $myarray['description']=$row['description'];
        $myarray['gender']=$row['gender'];
        $myarray['animaltype']=$row['type'];
        $myarray['color']=$row['color'];
        $myarray['breed']=$row['breed'];
        $myarray['image']=$row['animalImage'];
        $myarray['userId']=$row['sender_id'];
        $myarray['adoptedBy']=$row['name'];
        $myarray['address']=$row['address'];
        $myarray['phone']=$row['phone'];
       // $list[]=$row;
       array_push($list,$myarray);

    }   

} 
else{
   $myarray['result']="failed";
   
    array_push($list,$myarray);
  //  $list='Failed';
 
}
echo json_encode($list);
?>
