
<?php
include 'connect.php';
//s$office_id=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT collected_tb.animal_id,collected_tb.office_id,animal_tb.description,animal_tb.gender,animal_tb.type,animal_tb.color,animal_tb.breed,animal_tb.image,office.location,office.phone FROM collected_tb inner join animal_tb on collected_tb.animal_id=animal_tb.animal_id inner Join office on collected_tb.office_id=office.log_id where status='fostering' ;");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;
       $myarray['animalID']=$row['animal_id'];
       $myarray['officeID']=$row['office_id'];
       $myarray['description']=$row['description'];
    $myarray['gender']=$row['gender'];
    $myarray['type']=$row['type'];
    $myarray['color']=$row['color'];
    $myarray['breed']=$row['breed'];
    $myarray['image']=$row['image'];
    $myarray['office']=$row['location'];
    $myarray['phone']=$row['phone'];
    // $myarray['user_id']=$row['user_id'];
    $myarray['result']="success";

    array_push($list,$myarray);

    }   

} 
else{
   // $list='Failed';
   $myarray['result']="failed";
   array_push($list,$myarray);
 
}
echo json_encode($list);
?>
