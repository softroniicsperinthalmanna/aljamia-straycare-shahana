
<?php
include 'connect.php';
$uid=$_POST['officeId'];


$data=mysqli_query($conn,"SELECT * from office INNER JOIN login on office.log_id=login.log_id where office.log_id='$uid'");
 $list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;
    $myarray['location']=$row['location'];
    $myarray['phone']=$row['phone'];
    $myarray['email']=$row['email'];
    $myarray['result']="success";


    // $myarray['dateandtime']=$row['dateandtime'];
    
   // $myarray['user_id']=$row['user_id'];

   // array_push($list,$myarray);

    }   

} 
else{
    $myarray['result']="failed";
  //  array_push($list,$myarray);
   // $list='Failed';
 
}
// echo json_encode($list);
echo json_encode($myarray);
?>
