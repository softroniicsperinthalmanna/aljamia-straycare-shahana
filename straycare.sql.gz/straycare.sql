-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2023 at 11:31 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `straycare`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoption`
--

CREATE TABLE `adoption` (
  `adoption_id` int(10) NOT NULL,
  `date` datetime(6) NOT NULL,
  `user_id` int(10) NOT NULL,
  `animal_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption`
--

INSERT INTO `adoption` (`adoption_id`, `date`, `user_id`, `animal_id`) VALUES
(0, '0000-00-00 00:00:00.000000', 4567, 3245),
(0, '0000-00-00 00:00:00.000000', 4567, 3245),
(0, '0000-00-00 00:00:00.000000', 4567, 3245);

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `collection_id` int(10) NOT NULL,
  `date` datetime(6) NOT NULL,
  `user_id` int(10) NOT NULL,
  `animal_id` int(15) NOT NULL,
  `office_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`collection_id`, `date`, `user_id`, `animal_id`, `office_id`) VALUES
(1, '2002-12-12 00:00:00.000000', 23, 34, 23),
(2, '2002-12-12 00:00:00.000000', 23, 34, 23);

-- --------------------------------------------------------

--
-- Table structure for table `dead`
--

CREATE TABLE `dead` (
  `death_id` int(10) NOT NULL,
  `reason` varchar(200) NOT NULL,
  `date` datetime(6) NOT NULL,
  `animal_id` int(15) NOT NULL,
  `office_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dead`
--

INSERT INTO `dead` (`death_id`, `reason`, `date`, `animal_id`, `office_id`) VALUES
(1, 'heart attack', '0000-00-00 00:00:00.000000', 3456, 5678),
(2, 'heart attack', '0000-00-00 00:00:00.000000', 3456, 5678);

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE `donation` (
  `donation_id` int(10) NOT NULL,
  `type` varchar(50) NOT NULL,
  `user_id` int(10) NOT NULL,
  `amount` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`donation_id`, `type`, `user_id`, `amount`) VALUES
(1, 'gpay', 1234, 4200000);

-- --------------------------------------------------------

--
-- Table structure for table `foster`
--

CREATE TABLE `foster` (
  `animal_id` int(12) NOT NULL,
  `image` blob NOT NULL,
  `description_vet` varchar(200) NOT NULL,
  `veterinary_id` int(10) NOT NULL,
  `place_collected` varchar(300) NOT NULL,
  `date_collected` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foster`
--

INSERT INTO `foster` (`animal_id`, `image`, `description_vet`, `veterinary_id`, `place_collected`, `date_collected`) VALUES
(1, 0x746667686b6c, 'rfyghioj', 1234, '', '0000-00-00 00:00:00.000000'),
(2, 0x746667686b6c, 'rfyghioj', 1234, '', '0000-00-00 00:00:00.000000'),
(3, 0x746667686b6c, 'rfyghioj', 1234, 'fytdrwruty', '0000-00-00 00:00:00.000000'),
(4, 0x746667686b6c, 'rfyghioj', 1234, 'fytdrwruty', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `localselfgovernment`
--

CREATE TABLE `localselfgovernment` (
  `local_id` int(10) NOT NULL,
  `local_name` varchar(50) NOT NULL,
  `institution_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `localselfgovernment`
--

INSERT INTO `localselfgovernment` (`local_id`, `local_name`, `institution_type`) VALUES
(1, 'ghhgug', 'tfuugydtd');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `login_id` varchar(50) NOT NULL,
  `code` varchar(8) NOT NULL,
  `authority_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `missing`
--

CREATE TABLE `missing` (
  `missing_id` int(10) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `dateandtime` datetime(6) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `image` blob NOT NULL,
  `animal_type` varchar(25) NOT NULL,
  `status` varchar(150) NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `missing`
--

INSERT INTO `missing` (`missing_id`, `description`, `location`, `dateandtime`, `phone`, `image`, `animal_type`, `status`, `user_id`) VALUES
(1, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, '', '', 1234567),
(2, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, '', '', 1234567),
(3, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, '', '', 1234567),
(4, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, 'cat', 'leg fracture', 1234567),
(5, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, 'cat', 'leg fracture\n', 1234567),
(6, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, 'cat', 'leg fracture\n', 1234567),
(7, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, 'cat', 'leg fracture\n', 1234567),
(8, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, 0x6c6f676f2e706e67, 'cat', 'leg fracture\n', 1234567),
(9, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, '', 'cat', 'leg fracture', 1234567),
(10, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 3452678909, '', 'cat', 'leg fracture', 1234567);

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `office_id` int(10) NOT NULL,
  `location` varchar(200) NOT NULL,
  `phone` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`office_id`, `location`, `phone`) VALUES
(1, '2345678f', 1212121212);

-- --------------------------------------------------------

--
-- Table structure for table `register_tb`
--

CREATE TABLE `register_tb` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` blob NOT NULL,
  `address` varchar(300) NOT NULL,
  `log_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register_tb`
--

INSERT INTO `register_tb` (`user_id`, `name`, `image`, `address`, `log_id`) VALUES
(1, 'swalih', '', '', 7),
(2, 'Ashiq', '', '', 8),
(3, 'rishma', '', '', 9),
(4, 'shameela', '', '', 10),
(5, '', '', '', 11);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(10) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(250) NOT NULL,
  `dateandtime` datetime(6) NOT NULL,
  `image` blob NOT NULL,
  `case_type` varchar(25) NOT NULL,
  `user_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `description`, `location`, `dateandtime`, `image`, `case_type`, `user_id`) VALUES
(1, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'abuse', 1),
(2, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'vet', 2),
(3, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'wild', 7),
(4, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'aggressive', 2),
(5, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'missing', 3),
(6, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6c6f676f2e706e67, 'missing', 1),
(7, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', '', 'missing', 1234567),
(8, 'nfekfkewfknk', 'knbvshvsk', '0000-00-00 00:00:00.000000', 0x6162757365616e692e6a7067, 'missing', 1234567),
(9, 'this is a logo', 'pmna', '0000-00-00 00:00:00.000000', 0x6c6f676f2e6a7067, 'missing', 101),
(10, 'oqju', 'pmna', '0000-00-00 00:00:00.000000', 0x4869742d612d646565722e6a7067, 'missing', 101),
(11, 'oqju vxb xax hasbxhdbjs shbxhjbxd', 'kozhikode', '2025-02-05 00:00:00.000000', 0x4869742d612d646565722e6a7067, 'wild', 8),
(12, 'oqju vxb xax hasbxhdbjs shbxhjbxd', 'kozhikode', '2025-02-05 00:00:00.000000', 0x616767616e692e6a7067, 'aggressive', 8),
(13, 'wxwxwwswsws', 'kozhikode', '2025-02-05 00:00:00.000000', 0x616767616e692e6a7067, 'aggressive', 9);

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(10) NOT NULL,
  `station_name` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`station_id`, `station_name`, `phone`) VALUES
(1, 'melattur', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `log_id` int(11) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `password` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`log_id`, `phone`, `password`) VALUES
(1, 0, 0),
(2, 0, 0),
(3, 0, 0),
(4, 2147483647, 1234567890),
(5, 9074230412, 123123),
(6, 9074230412, 123123),
(7, 9074230412, 123123),
(8, 7098767876, 123123),
(9, 7090990088, 123456),
(10, 9087880012, 123456),
(11, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `veterinary`
--

CREATE TABLE `veterinary` (
  `vet_id` int(10) NOT NULL,
  `clinic_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `veterinary`
--

INSERT INTO `veterinary` (`vet_id`, `clinic_name`) VALUES
(1, ''),
(2, ''),
(3, ''),
(4, 'melattur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`collection_id`);

--
-- Indexes for table `dead`
--
ALTER TABLE `dead`
  ADD PRIMARY KEY (`death_id`);

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`donation_id`);

--
-- Indexes for table `foster`
--
ALTER TABLE `foster`
  ADD PRIMARY KEY (`animal_id`);

--
-- Indexes for table `localselfgovernment`
--
ALTER TABLE `localselfgovernment`
  ADD PRIMARY KEY (`local_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `missing`
--
ALTER TABLE `missing`
  ADD PRIMARY KEY (`missing_id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `register_tb`
--
ALTER TABLE `register_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `veterinary`
--
ALTER TABLE `veterinary`
  ADD PRIMARY KEY (`vet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `collection_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dead`
--
ALTER TABLE `dead`
  MODIFY `death_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `donation`
--
ALTER TABLE `donation`
  MODIFY `donation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `foster`
--
ALTER TABLE `foster`
  MODIFY `animal_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `localselfgovernment`
--
ALTER TABLE `localselfgovernment`
  MODIFY `local_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `missing`
--
ALTER TABLE `missing`
  MODIFY `missing_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `office_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `register_tb`
--
ALTER TABLE `register_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `station_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `veterinary`
--
ALTER TABLE `veterinary`
  MODIFY `vet_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
